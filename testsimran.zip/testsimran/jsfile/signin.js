function signin(){
  var Username= document.getElementById('username').value;
  var Password = document.getElementById('password').value;

  if (username=="simran" && password=="simran"){
    window.location ="acc.html";
    
    return false;
  }
  else {
    alert("re-enter your username and password");
  }

}
