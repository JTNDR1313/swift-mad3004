

function getinfo(){
var email = document.getElementById("email").value;
var password = document.getElementById("password").value;

  if (email=="jtndr" && password=="jtndr"){
  window.location ="menu.html?Email" + email;
return false;
}
else if (email=="kang" && password=="kang") {
  window.location ="menu.html";
  return false;

}
  else{
    alert("sorry...please check your email and password");
  }
}

function uname(){
  UName = location.search.substring(1).split("=");
  document.getElementById().innerHTML = UName;
}
