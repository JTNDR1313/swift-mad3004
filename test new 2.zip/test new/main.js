  var currentBalanceInput = document.getElementById('currentbalance');
  var amountInput = document.getElementById('amount');
  var finalBalanceInput = document.getElementById('leftbalance');
  var labelTransferMessage = document.getElementById('moneyTransferMessage');
  var labelAccNumber = document.getElementById('lblmessage');
  var otherAccNumber = document.getElementById('tonew');

var btn = document.getElementById('calculate');

  otherAccNumber.style.display = "none";
  var balance = 2000;



setCurrentBalance();

function setCurrentBalance() {

currentBalanceInput.value = balance ;
}


   function toacc(){
        var x = document.getElementById("toaccount").value;

        if(x == "Other"){
         otherAccNumber.style.display = "block";
      }else {
             otherAccNumber.style.display = "none";
               }

}


btn.addEventListener('click',onCalculate);

function onCalculate() {
  var ai = amountInput.value;
    balance-=ai;
      finalBalanceInput.value = balance;
      currentBalanceInput.value = balance;

if (currentBalanceInput.value <=0){
  alert("sorry...please add amount to your account");
}
else{

}



}
