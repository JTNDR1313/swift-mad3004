//
//  ViewController.swift
//  project
//
//  Created by harpreet virk on 2018-08-15.
//  Copyright © 2018 harpreet virk. All rights reserved.
//

import UIKit

class Login: UIViewController {

    @IBOutlet weak var txtemail: UITextField!
    
    @IBOutlet weak var txtpassword: UITextField!
    
    
    @IBOutlet weak var `switch`: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    @IBAction func btnsignin(_ sender: Any) {
    
    
        
       
        
    }
        
        
    
   
    @IBAction func btnsignup(_ sender: Any) {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let signUpVC = mainSB.instantiateViewController(withIdentifier: "registerScene")
        navigationController?.pushViewController(signUpVC, animated: true)
        
        
    }
    

}

