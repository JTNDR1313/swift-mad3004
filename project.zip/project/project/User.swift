//
//  User.swift
//  project
//
//  Created by harpreet virk on 2018-08-15.
//  Copyright © 2018 harpreet virk. All rights reserved.
//

import Foundation

    class User{
        var name: String!
        var address: String!
        var contactNumber: String!
        var email: String!
        var password: String!
        var dob: Date!
        
        static var userList = [String: User]()
        
        init() {
            self.name = ""
            self.address = ""
            self.contactNumber = ""
            self.email = ""
            self.password = ""
            self.dob = Date()
        }
        
        init(name: String, address: String, contactNumber: String,  email: String, password: String, dob: Date) {
            self.name = name
            self.address = address
            self.contactNumber = contactNumber
            self.email = email
            self.password = password
            self.dob = dob
        }
        
        static func addUser(newUser: User) -> Bool{
            if self.userList[newUser.email] == nil{
                self.userList[newUser.email] = newUser
                return true
            }
            
            return false
        }
        
        static func searchUser(email: String) -> User? {
            if self.userList[email] != nil{
                return self.userList[email]
            }
            
            return nil
        }
        
        static func deleteUser(email: String) -> Bool{
            if self.userList[email] != nil{
                self.userList[email] = nil
                return true
            }
            
            return false
        }
    }
    

