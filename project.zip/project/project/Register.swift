//
//  Register.swift
//  project
//
//  Created by harpreet virk on 2018-08-15.
//  Copyright © 2018 harpreet virk. All rights reserved.
//

import UIKit

class Register: UIViewController {
    
    
    @IBOutlet weak var txtName: UITextField!
    
    
    @IBOutlet weak var txtcontact: UITextField!
    
    
    @IBOutlet weak var txtaddress: UITextField!
    
    @IBOutlet weak var txtemail: UITextField!
    
    @IBOutlet weak var txtpassword: UITextField!
    
    
    @IBOutlet weak var pickDob: UIDatePicker!
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = "Sign Up"
        navigationController?.setNavigationBarHidden(false, animated: true)
        
        let btnSubmit = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(displayInfo))
        self.navigationItem.rightBarButtonItem = btnSubmit
    
    
    
}
    
    
    @objc func displayInfo(){
        var userInfo : String = txtName.text!
        userInfo += "\n" + txtcontact.text!
        userInfo += "\n" + txtaddress.text!
        userInfo += "\n" + txtemail.text!
        userInfo += "\n" + txtpassword.text!
        userInfo += "\n \(pickDob.date)"
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
}
