//
//  main.swift
//  employee
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var jtndr = PermanentEmp(empID: 110, empName: "jtndr", basicPay: 10000.00, holiday: 3)
jtndr.display()



var arsh = Tempemp(empID: 111, empName: "asrh", basicPay: 2548.00, holiday: 60)
arsh.display()





print("7 is a prime no. : \(7.isPrime)")
print("1 is a prime no. : \(1.isPrime)")
print("2 is a prime no. : \(2.isPrime)")
print("12 is a prime no. : \(12.isPrime)")

//  extensions for functions
4.wish {
    print("prty nvdeep")
    
    
    // extension for subscript
    
    print(25976413[6])
    
    
}
