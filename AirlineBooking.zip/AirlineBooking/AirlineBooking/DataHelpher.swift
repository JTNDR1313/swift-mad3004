//
//  DataHelpher.swift
//  AirlineBooking
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    var AirlineList = [Int : Airline]()
    
    init(){
        self.loadAirlineData()
    }
    
    func loadAirlineData(){
        AirlineList = [:]
        
        let AirIndia = Airline(airlineID : 100, airlineDescription : "One of the best indian airline" , airlineType : "International" )
        AirlineList[AirIndia.AirlineID!] = AirIndia
        let AirCanada = Airline(airlineID : 101, airlineDescription : "First Canadian airline" , airlineType : "International" )
        AirlineList[AirCanada.AirlineID!] = AirCanada
        let Etihad = Airline(airlineID : 102, airlineDescription : "Most preffeble airline" , airlineType : "International" )
        AirlineList[AirIndia.AirlineID!] = Etihad
        let JetAirways = Airline(airlineID : 103, airlineDescription : "Common airline" , airlineType
            :"National" )
        AirlineList[JetAirways.AirlineID!] = JetAirways
    }
    func displayAirline(){
        for (_, value) in self.AirlineList.sorted(by: { $0.key < $1.key} ){
            print(value.displayData())
        }
    }
}
