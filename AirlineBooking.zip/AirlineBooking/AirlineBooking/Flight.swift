//
//  Flight.swift
//  AirlineBooking
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Flight{
    
    private var flightID : String?
    
    private var flightFrom : String?
    
    private var flightTo : String?
    
    private var flightScheduleDate : String?
    
    private var flightAirlineId : Int?
    
    private var flightAirplaneId : String?
    
    private var flightPilotId : String?
    
    
    
    var FlightID : String?{
        
        get{
            
            return self.flightID
            
        }
        
        set{
            
            self.flightID = newValue
            
        }
        
}

    
}


