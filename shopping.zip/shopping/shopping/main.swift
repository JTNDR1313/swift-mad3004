//
//  main.swift
//  shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var jtndr = Customer()

print(jtndr.displayData())

var arsh = Customer(customerID: 101, customerName: "arsh, ", address: "attmar dr.., ", email: "arsh@gmail.com, ", creditCardInfo: "1234568945452,  ", shippingInfo: "attamr dr. ")
print(arsh.displayData())


jtndr.CustomerID = 102
jtndr.CustomerName = "jatinder, "
jtndr.Address = "brampton, "
jtndr.Email = "js@gmail.com, "
jtndr.CreditcardInfo = "1124-4567-4598-4785, "
jtndr.ShippingInfo = "ghfsydgiergyfouog "
print(jtndr.displayData())




var smrn = Customer()
smrn.registerUser()
print(smrn.displayData())
