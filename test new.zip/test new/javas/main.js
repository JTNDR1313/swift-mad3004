  var currentBalanceInput = document.getElementById('currentbalance');
  var amountInput = document.getElementById('amount');
  var finalBalanceInput = document.getElementById('leftbalance');
  var labelMoneyTransferMessage = document.getElementById('moneyTransferMessage');
  var labelAccNumber = document.getElementById('lblmessage');
  var accNumberInput = document.getElementById('tonew');
  var otherAccNumber = document.getElementById('tonew');



function toacc(){
  var x = document.getElementById("toaccount").value;

  if(x.match("Other")){
       labelAccNumber.style.display = "block";
         accNumberInput.style.display = "block";

      else {
             otherAccNumber.value = "";
             otherAccNumber.style.display = "none";
             labelAccNumber.style.display = "none";
                 accNumberInput.style.display = "none";

               }
                   }
}
