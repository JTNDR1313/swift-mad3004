//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var coordinates = (1,20)

switch coordinates {
case (0,0):
    print("Start of canvas")
case(100,100):
    print("End of canvas")
case(1,20):
    print("Center of canvas")
case(1,_):
    print ("x axis")
case(_,20):
    print("y axis")
case(101...200,101...200):
    print("outside the canvas")
default:
    print("Canvas unavailable")
}


var range = 1...100
print(range)
print(range.contains(45))
print(range.contains(35))

print("Lowerbound",range.lowerBound)
print("upperbound",range.upperBound)


for itr in 0...5{
    print("itr : \(itr)")
}
for itr in 0..<5{
    print("itr : \(itr)")
}


var friends = ["arsh","jtndr","simrn","prabh"]

var length = friends.count

for itr in 0..<length{
    //print("friends : \(itr)")
    print("friends : \(friends[itr])")
}

for frnd in friends[1...]{
    print("===\(frnd )")
}

for frnd in friends[...2]{
    print("@@@ \(frnd)")    
}

for char in "Good😘"{
    print("character : \(char)")
}


var jtnder = """
answer to question
      what would it be
you r nt wrkng.
Respose :: i dnt know
"""
print(jtnder)
 //appamdment
jtnder += "i would be singer"
jtnder.append("ohh really !!!🙄  ")
print(jtnder)

   //startIndex

var day = "saturday"
//saturday_
print("startIndex : \(day[day.startIndex])")

//print("endIndex : \(day[day.endIndex])")
//can never print end index

print("last character : \(day[day.index(before: day.endIndex)])")

print("second character : \(day[day.index(after:day.startIndex)])")

print("4th character : \(day[day.index(day.startIndex,offsetBy : 4)])")

print("4th character : \(day[day.index(day.startIndex,offsetBy : 3)])")

print("3th from last : \(day[day.index(day.endIndex,offsetBy : -2)])")

print("3th from last : \(day[day.index(day.endIndex,offsetBy : -3)])")

var index =  day.index(of :"t") ??
      day.endIndex
print("char t : \(day[index])")

 // for all character
for idx in day.indices{
    print("\(day[idx])")
}

for idx in day.indices{
    print("\(day[idx])",terminator: "_")
}
 print("test")

// for index and char. both
for (idx,char)in day.enumerated(){
    print("Index: \(idx) Char : \(char)")
    
    print(day.uppercased())
    print(day.lowercased())
    
    day.insert("!", at : day.endIndex)
    print(day)

    day.insert(contentsOf: " no class please", at : day.endIndex)
    print(day)

    var idx1 =  day.index(of: "!") ?? day.endIndex
    day.remove(at : idx1)
    print(day)
    
    idx1 = day.index(of : "N") ?? day.endIndex
    var idx2 = day.index(of: "s") ?? day.endIndex
    day.removeSubrange(idx1...idx2)
    print(day)
    
    
    day.removeAll()
    print("day :",day)
}










//var value =  String()
//value ="too much"

//if value.isEmpty{
 //   print("value not available")
//}
//else{
//    print(value)
//}

