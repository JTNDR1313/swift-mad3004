//
//  ViewController.swift
//  jtndr
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelname: UILabel!
    
    @IBOutlet weak var password: UILabel!
    
    @IBOutlet weak var txtusername: UITextField!
    
    @IBOutlet weak var txtpassword: UITextField!
    
    @IBOutlet weak var btnlogin: UIButton!
        
    @IBOutlet weak var btnregister: UIButton!
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        
//        Do any additional setup after loading the view, typically from a nib.
    }
   
    
    @IBAction func button(_ sender: Any) {
      let clickedButton = sender as! UIButton
        if clickedButton.tag == 1{
            btnregister.isHidden = false
            btnlogin.isHidden = true
            
        } else if clickedButton.tag == 2 {
            btnregister.isHidden = true
            btnlogin.isHidden = false
        
        }
    }
   
    override func didReceiveMemoryWarning()
    {
        
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

