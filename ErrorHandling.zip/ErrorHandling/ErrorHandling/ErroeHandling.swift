//
//  ErroeHandling.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class RquestLimitIncrease{
    var accountInfo = [
        
    "S1100" : AcInfo(type: "Saving" , balance: 2313.21),
    "S1200" : AcInfo(type: "Saving" , balance: 4500.00),
    "S1300" : AcInfo(type: "Cheqing" , balance: 5313.21),
    "S1400" : AcInfo(type: "Saving" , balance: 7255.21)
    
    ]
    func processRequest(accountNo: String) throws{
        guard let accNo = accountInfo[accountNo]
            else{throw LimitIncreaseErrors.ineligible
                
        }
        guard  accNo.type == "Saving"
            else{throw LimitIncreaseErrors.noSavingAc
                
        }
        
        guard  accNo.balance >= 5000.00
        else{throw LimitIncreaseErrors.insufficientBalance
            
        }
        print("Congo...! your credit limit is increased")
    }
    
    
}


struct AcInfo {
    var type: String
    var balance:  Double
}
enum LimitIncreaseErrors: Error{
    case ineligible
    case noSavingAc
    case insufficientBalance
}
