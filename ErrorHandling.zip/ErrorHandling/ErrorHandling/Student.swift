//
//  Student.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//final class Student{
// private class Student {
class Student{
    var name: String?
   private static var acNo : Int?
    
    
    
    init(){
        self.name = "unknown"
        Student.acNo = 123134
    }
    
    func display(){
        print("Student name : \(self.name ?? "unknown")")
        print("Ac No : \(Student.acNo ?? 0)")
        
    }
    
     static func getAcNo() -> Int{
        
        return  acNo!
    }
}
class PartTime: Student {
    var hours : Int?
    override init() {
        self.hours = 10
        super .init()
    }
    
    
    override func display() {
        print("Hours : \(self.hours ?? 0)")
    }
}
