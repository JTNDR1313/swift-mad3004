//
//  main.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")


var request1 = RquestLimitIncrease()



do{
    

try request1.processRequest(accountNo: "S1400")
}
catch LimitIncreaseErrors.ineligible{
    print("you don't have acc . Request rejected")
}
catch LimitIncreaseErrors.noSavingAc{
    print("credit only increase if u have saving acc.")
}
catch LimitIncreaseErrors.insufficientBalance{
    print("u need min. 5000 to increase ur credit limit ")
}
catch{
    print("SErvice disrupted.... sorry for inconvience")
}


do

{
    
}

// Static
var  s1 = Student()
s1.name = "jtndr"

s1.display()



var s2 = Student()
s2.name = "arsh"
s2.display()







