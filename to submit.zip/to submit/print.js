function print(){
  var doc = new jspdf();

      doc.setFontSize(10);
      doc.text(2,12,'ACCOUNT HOLDER NAME');
      doc.setFontSize(5);
      doc.text(2,14,'STREET ADDRESS,');
      doc.text(2,16,'CITY, PROVINCE, POSTAL CODE');


      doc.text(2,25,'PAY TO THE');
      doc.text(2,27,'ORDRE OF ________________________________________________________________________________________ $');
      doc.rect(115, 25, 30, 5);
      doc.text(2,33,'______________________________________________________________________________________/100 DOLLARS');
      doc.setFontSize(10);
      doc.text(2,37,'BANK NAME');
      doc.setFontSize(5);
      doc.text(2,39,'BANK STREET ADDRESS,');
      doc.text(2,41,'BANK CITY, PROVINCE, POSTAL CODE');
      doc.text(2,48,'"001"                    :05550                    004                    127864182178 "');
      doc.text(2,51,'                     Branch Transit                Bank Id                  Bank Account "');
      doc.text(2,53,'                        Number                      Number                     Number');


      doc.setFontSize(25);
      doc.text(66,34,'VOID');
      doc.save('print.pdf');
  }
