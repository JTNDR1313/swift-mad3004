  var currentBalanceInput = document.getElementById('currentbalance');
  var amountInput = document.getElementById('amount');
  var finalBalanceInput = document.getElementById('leftbalance');
  var labelTransferMessage = document.getElementById('moneyTransferMessage');

  var otherAccNumber = document.getElementById('tonew');
  var creditbalanceInput = document.getElementById('Totalcreditbalance');
  var creditbalanceleft = document.getElementById('creditleft');
var btn = document.getElementById('calculate');

  otherAccNumber.style.display = "none";


  var balance = 2500;
     setCurrentBalance();

function setCurrentBalance() {

currentBalanceInput.value = balance ;
}



 function toacc(){
        var x = document.getElementById("toaccount").value;

        if(x == "Other"){
         otherAccNumber.style.display = "block";
      }else {
             otherAccNumber.style.display = "none";
               }

}
function fromacc(){
  var x = document.getElementById("fromaccount").value;
  if(x == "SavingAccount"){
    currentbalance.value = 1000;

}else if (x == 'CheckingAccount'){
       currentbalance.value = 1500;
     } else{
       currentBalanceInput.value = balance;
     }
}


btn.addEventListener('click',onCalculate);

function onCalculate() {
  var ai = amountInput.value;

  balance-=ai;
      finalBalanceInput.value = balance;
      currentBalanceInput.value = balance;


    if (currentBalanceInput.value <=0){
        alert("sorry...please add amount to your account");
          }
          else{
            var newb = Currentbalance - val;
            document.getElementById("leftbalance").value = newb;

            }
                }
var creditbalance = 1000;
setCreditBalance();

function setCreditBalance(){

creditbalancetInput.value = creditbalance;
}
