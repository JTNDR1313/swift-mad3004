//
//  DataHelpher.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    var AirlineList = [Int : Airline]()
    
    init(){
        self.loadAirlineData()
    }
    
    func loadAirlineData(){
        AirlineList = [:]
        
        let Alitalia = Airline(airlineID : 001, airlineDescription : "Italian airline" , airlineType : "International" )
        AirlineList[Alitalia.AirlineID!] = Alitalia
        
        let AirCanada = Airline(airlineID : 002, airlineDescription : " Canadian airline" , airlineType : "International" )
        AirlineList[AirCanada.AirlineID!] = AirCanada
        
        let Etihad = Airline(airlineID : 003, airlineDescription : "Most Expensive airline" , airlineType : "International" )
        AirlineList[Etihad.AirlineID!] = Etihad
        
        let JetAirways = Airline(airlineID :004, airlineDescription : "Common airline" , airlineType
            :"National" )
        AirlineList[JetAirways.AirlineID!] = JetAirways
        
        let CathayPacific = Airline(airlineID : 005, airlineDescription : "Prefferable airline" , airlineType : "International" )
        AirlineList[CathayPacific.AirlineID!] = Etihad    }
    
    
    func displayAirline(){
        for (_, value) in self.AirlineList.sorted(by: { $0.key < $1.key} ){
            print(value.displayData())
        }
    }
}
