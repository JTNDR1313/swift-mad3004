//
//  Reservation.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Reservation {
    var reservationID : Int?
    private var description : String?
    private var passengerID : String?
    private var flightID : String?
    private var seatNumber : String?
    private var status : String?
    private var mealType : String?
    
    
    
    
    
    var ReservationID :Int?{
        get{ return self.reservationID}
        set{ self.reservationID = newValue }
    }
    
    var Description: String?{
        get{ return self.description }
        set{ self.description = newValue }
    }
    
    var PassengerID : String?{
        get { return self.passengerID}
        set {self.passengerID = newValue}
    }
    var FlightID: String?{
        get { return self.flightID}
        set {self.flightID = newValue}
    }
    var SeatNumber : String?{
        get { return self.seatNumber}
        set {self.seatNumber = newValue}
    }
    var Status : String?{
        get { return self.status}
        set {self.status = newValue}
    }
    var MealType : String?{
        get { return self.mealType}
        set {self.mealType = newValue}
    }
    
    
    init(){
        self.reservationID = 0
        self.description = ""
        self.passengerID = ""
        self.flightID = ""
        self.seatNumber = ""
        self.status = ""
        self.mealType = ""
    }
    
   
    init(reservationID: Int, description : String, passengerID : String, flightID : String, seatNumber : String, status : String , mealType : String){
        
        self.reservationID = reservationID
        self.description = description
        self.passengerID = passengerID
        self.flightID = flightID
        self.seatNumber = seatNumber
        self.status = status
        self.mealType = mealType
}
    
    func displayData() -> String{
        var returnData = ""
        
        if self.reservationID != nil{
            returnData += "\n Reservation Id: \(self.reservationID ?? 0)"
        }
        if self.description != nil{
            returnData += "\n Description:" +  self.description!
        }
        if self.passengerID != nil{
            returnData += "\n Passenger ID:" +  self.passengerID!
        }
        if self.flightID != nil{
            returnData += "\n FlightID:" +  self.flightID!
        }
        if self.seatNumber != nil{
            returnData += "\n Seat Number:" +  self.seatNumber!
        }
        if self.status != nil{
            returnData += "\n Status:" +  self.status!
        }
        if self.mealType != nil{
            returnData += "\n Meal Type:" +  self.mealType!
        }
        return returnData
    }
    }
