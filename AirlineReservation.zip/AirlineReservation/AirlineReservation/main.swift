//
//  main.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

//var navdeep = Employee()
//navdeep.registerUser()
//print(navdeep.displayData())
